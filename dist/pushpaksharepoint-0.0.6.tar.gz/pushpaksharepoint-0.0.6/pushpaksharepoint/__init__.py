from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.client_credential import ClientCredential
import pandas as pd



class sharepointconnect:
    def __init__(self,url,client_id,client_secret,title):
        self.url = url
        self.client_id = client_id
        self.client_secret = client_secret
        self.title = title
        data = []
        
    def connet_sharepoint(client_id,client_secret):
        self.client_id=client_id
        self.client_secret=client_secret
        client_credentials = ClientCredential(client_id,client_secret)
        ctx = ClientContext(url).with_credentials(client_credentials)
        print("Connection Was succesfully Establishe")
        return ctx

    def print_progress(self,items_read):
        print("Items read: {0}".format(items_read))

    def enum_items(self,target_list):
        items = target_list.items.top(1000)  # .top(1220)
        items.page_loaded += self.print_progress  # page load event
        ctx = self.connet_sharepoint(client_id, client_secret)
        ctx.load(items)
        ctx.execute_query()
        output = pd.DataFrame()
        for index, item in enumerate(items):
            #print(item.properties)
            a = item.properties
            output = output.append(a, ignore_index=True)
            #print("{0}: {1}".format(index, item.properties['Color']))
        output = output.loc[:,~output.columns.duplicated()]
        output.to_csv('data.csv',index=False)
        return output
  

    def return_list(self):
        ctx = self.connet_sharepoint(self.client_id,self.client_secret)
        ccc_list = ctx.web.lists.get_by_title(title)
        return self.enum_items(ccc_list)
   


